# QustodioBypass
Facing the tyranny of being enslaved by ur parents digital monitor Qustodio? Fear no more as we share the same experience, this will help you disable Qustodio

# Support
- Win 10/7 (Only tested on Win 10)
- iOS
- Mac

# Downloading/Usage
Read the README.md file for which folder to download and how to use scripts
