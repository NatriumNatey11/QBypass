# Here is the most reliable way we have found for IOS as of yet
Go read the workaround.txt file
